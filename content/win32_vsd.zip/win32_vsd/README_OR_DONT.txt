extract "win32_vsd" folder
start exe from "data" folder

CONTROLS:
W
A
S
D

press E to see 360g radiant func

press and move L Mouse

u can use arrows to move cat